#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define Quantium 5
#define buffersize 255
#define limiteprocessos 100
#define naocompleto 0 
#define completado 1 

const char token[2] = ";";

typedef struct {
    char ID[5];
    int DURATION;
    int PRIORITY;
    int STATUS;
    char PROGRAM[255];
    char USER[255];
} Process;


Process process[limiteprocessos];

void Listaprocessos(Process *process, int swapA, int size) 
{
    Process aux = process[swapA];
    for(int i = swapA; i < size - 1; i ++)  
    {
        process[i] = process[i+1];
    }
    process[size - 1] = aux;
}

int main(int argc, char const *argv[])
{
    FILE *file;

    Process proc;
    char buffer[buffersize];
    char *value;
    int count = 0;

		file = fopen("processo.txt", "r");
		
		if (file == NULL) {
		    printf("erro ao tentar abrir arquivo\n");
		    return 1;
		}
		
		printf("Arquivo lido\n");


    printf("Iniciar escalonamento\n\n");
  
	while(fgets(buffer, buffersize, file)) 
	{
	    value = strtok(buffer, token);
	    strcpy(proc.ID, value);
	    value = strtok(NULL, token);
	    proc.DURATION = atoi(value);
	    value = strtok(NULL, token);
	    proc.PRIORITY = atoi(value);
	    value = strtok(NULL, token);
	    strcpy(proc.PROGRAM, value);
	    value = strtok(NULL, token);
	    strcpy(proc.USER, value);
	    proc.STATUS = naocompleto;
	    process[count] = proc;
	    count++;
	}

    fclose(file);

    int Nao_Processados = count;
    int currentProcIndex = 0;

    Process *currentProc;

while(Nao_Processados > 0) 
{
    int highestPriority = -1;
    int highestPriorityIndex = -1;
    for(int i = 0; i < count; i++) 
    {
        if(process[i].STATUS == naocompleto && process[i].PRIORITY > highestPriority) 
        {
            highestPriority = process[i].PRIORITY;
            highestPriorityIndex = i;
        }
    }

    if(highestPriorityIndex == -1) 
    {
        break;
    }

    currentProc = &process[highestPriorityIndex];
    printf("Processo em execução : %s\n", currentProc->ID);
    printf("Tempo de execução restante : %i segundos\n", currentProc->DURATION);
    printf("Nivel de prioridade : %i\n", currentProc->PRIORITY);
    printf("Comando : %s\n", currentProc->PROGRAM);
		printf("Usuário : %s\n", currentProc->USER);

 if(currentProc->DURATION <= Quantium)
    {
        sleep(currentProc->DURATION);
        printf("Status: Processo %s completado. \n\n", currentProc->ID);
      
        Nao_Processados--;
        currentProc->STATUS = completado;
        currentProc->DURATION = 0;
    }
    else 
    {
        sleep(Quantium);
        printf("Status: Processo %s ainda não completado.\n\n", currentProc->ID);
        currentProc->DURATION -= Quantium;
        Listaprocessos(process, highestPriorityIndex, count);
    }
}
    return 0;
}
